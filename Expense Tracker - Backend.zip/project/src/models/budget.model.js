const mongoose = require('mongoose');

const BudgetSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    category: {
      type: String,
      required: [true, 'Please add a category'],
      trim: true
    },
    limit: {
      type: Number,
      required: [true, 'Please add a limit'],
      min: [0.01, 'Limit must be at least 0.01']
    },
    month: {
      type: Number,
      required: [true, 'Please add a month'],
      min: 1,
      max: 12
    },
    year: {
      type: Number,
      required: [true, 'Please add a year'],
      min: 2000,
      max: 2100
    }
  },
  {
    timestamps: true
  }
);

// Compound index to ensure unique budget per user, category, month, and year
BudgetSchema.index({ user: 1, category: 1, month: 1, year: 1 }, { unique: true });

/**
 * @swagger
 * components:
 *   schemas:
 *     Budget:
 *       type: object
 *       required:
 *         - category
 *         - limit
 *         - month
 *         - year
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated id of the budget
 *         category:
 *           type: string
 *           description: Category for this budget
 *         limit:
 *           type: number
 *           description: Budget limit amount
 *         month:
 *           type: number
 *           description: Month (1-12)
 *           minimum: 1
 *           maximum: 12
 *         year:
 *           type: number
 *           description: Year
 *       example:
 *         id: 60d0fe4f5311236168a109cd
 *         category: Food
 *         limit: 300
 *         month: 12
 *         year: 2023
 */

module.exports = mongoose.model('Budget', BudgetSchema);