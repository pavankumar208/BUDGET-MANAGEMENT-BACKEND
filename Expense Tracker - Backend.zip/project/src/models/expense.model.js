const mongoose = require('mongoose');

const ExpenseSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    amount: {
      type: Number,
      required: [true, 'Please add amount'],
      min: [0.01, 'Amount must be at least 0.01']
    },
    description: {
      type: String,
      required: [true, 'Please add a description'],
      trim: true,
      maxlength: [100, 'Description can not be more than 100 characters']
    },
    category: {
      type: String,
      required: [true, 'Please add a category'],
      trim: true
    },
    date: {
      type: Date,
      default: Date.now
    },
    paymentMode: {
      type: String,
      enum: ['cash', 'credit card', 'debit card', 'bank transfer', 'other'],
      default: 'cash'
    },
    tags: [String],
    isDeleted: {
      type: Boolean,
      default: false
    }
  },
  {
    timestamps: true
  }
);

// Index for faster queries
ExpenseSchema.index({ user: 1, date: -1 });
ExpenseSchema.index({ category: 1, user: 1 });

/**
 * @swagger
 * components:
 *   schemas:
 *     Expense:
 *       type: object
 *       required:
 *         - amount
 *         - description
 *         - category
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated id of the expense
 *         amount:
 *           type: number
 *           description: The expense amount
 *         description:
 *           type: string
 *           description: Description of the expense
 *         category:
 *           type: string
 *           description: Category of the expense
 *         date:
 *           type: string
 *           format: date-time
 *           description: Date of the expense
 *         paymentMode:
 *           type: string
 *           enum: [cash, credit card, debit card, bank transfer, other]
 *           description: Mode of payment
 *         tags:
 *           type: array
 *           items:
 *             type: string
 *           description: Optional tags for the expense
 *       example:
 *         id: 60d0fe4f5311236168a109cb
 *         amount: 29.99
 *         description: Groceries
 *         category: Food
 *         date: 2023-12-01T10:30:00Z
 *         paymentMode: credit card
 *         tags: [monthly, necessary]
 */

module.exports = mongoose.model('Expense', ExpenseSchema);