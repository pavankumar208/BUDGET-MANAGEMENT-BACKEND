const mongoose = require('mongoose');

const IncomeSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    amount: {
      type: Number,
      required: [true, 'Please add amount'],
      min: [0.01, 'Amount must be at least 0.01']
    },
    source: {
      type: String,
      required: [true, 'Please add a source'],
      trim: true,
      maxlength: [50, 'Source can not be more than 50 characters']
    },
    description: {
      type: String,
      trim: true,
      maxlength: [100, 'Description can not be more than 100 characters']
    },
    date: {
      type: Date,
      default: Date.now
    },
    recurring: {
      type: Boolean,
      default: false
    },
    recurringType: {
      type: String,
      enum: ['daily', 'weekly', 'monthly', 'yearly', null],
      default: null
    }
  },
  {
    timestamps: true
  }
);

// Index for faster queries
IncomeSchema.index({ user: 1, date: -1 });
IncomeSchema.index({ source: 1, user: 1 });

/**
 * @swagger
 * components:
 *   schemas:
 *     Income:
 *       type: object
 *       required:
 *         - amount
 *         - source
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated id of the income
 *         amount:
 *           type: number
 *           description: The income amount
 *         source:
 *           type: string
 *           description: Source of the income
 *         description:
 *           type: string
 *           description: Description of the income
 *         date:
 *           type: string
 *           format: date-time
 *           description: Date of the income
 *         recurring:
 *           type: boolean
 *           description: Whether the income is recurring
 *         recurringType:
 *           type: string
 *           enum: [daily, weekly, monthly, yearly, null]
 *           description: Type of recurrence if recurring
 *       example:
 *         id: 60d0fe4f5311236168a109cc
 *         amount: 3000
 *         source: Salary
 *         description: Monthly salary
 *         date: 2023-12-01T00:00:00Z
 *         recurring: true
 *         recurringType: monthly
 */

module.exports = mongoose.model('Income', IncomeSchema);