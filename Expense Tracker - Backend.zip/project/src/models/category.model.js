const mongoose = require('mongoose');

const CategorySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please add a name'],
      trim: true,
      maxlength: [50, 'Name can not be more than 50 characters']
    },
    type: {
      type: String,
      enum: ['expense', 'income'],
      required: [true, 'Please specify if this is an expense or income category']
    },
    icon: {
      type: String,
      default: 'default-icon'
    },
    color: {
      type: String,
      default: '#000000'
    },
    isDefault: {
      type: Boolean,
      default: false
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null // null for system categories
    }
  },
  {
    timestamps: true
  }
);

// Compound index to ensure unique categories per user
CategorySchema.index({ name: 1, type: 1, user: 1 }, { unique: true });

/**
 * @swagger
 * components:
 *   schemas:
 *     Category:
 *       type: object
 *       required:
 *         - name
 *         - type
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated id of the category
 *         name:
 *           type: string
 *           description: Name of the category
 *         type:
 *           type: string
 *           enum: [expense, income]
 *           description: Type of category
 *         icon:
 *           type: string
 *           description: Icon for the category
 *         color:
 *           type: string
 *           description: Color code for the category
 *         isDefault:
 *           type: boolean
 *           description: Whether this is a system default category
 *       example:
 *         id: 60d0fe4f5311236168a109ce
 *         name: Groceries
 *         type: expense
 *         icon: shopping-cart
 *         color: #00B8D9
 *         isDefault: true
 */

module.exports = mongoose.model('Category', CategorySchema);