const jwt = require('jsonwebtoken');
const { errorResponse } = require('./error.middleware');
const User = require('../models/user.model');

/**
 * Protect routes - Verify user is authenticated
 */
exports.protect = async (req, res, next) => {
  try {
    let token;
    
    // Check for token in headers
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      token = req.headers.authorization.split(' ')[1];
    }
    
    // Make sure token exists
    if (!token) {
      return errorResponse(res, 401, 'Not authorized to access this route');
    }
    
    try {
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      // Get user from database, excluding password
      req.user = await User.findById(decoded.id).select('-password');
      
      if (!req.user) {
        return errorResponse(res, 401, 'User not found');
      }
      
      next();
    } catch (error) {
      return errorResponse(res, 401, 'Not authorized to access this route');
    }
  } catch (err) {
    next(err);
  }
};

/**
 * Authorize based on user role
 */
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !req.user.role) {
      return errorResponse(res, 403, 'User role not defined');
    }
    
    if (!roles.includes(req.user.role)) {
      return errorResponse(
        res,
        403,
        `User role '${req.user.role}' is not authorized to access this route`
      );
    }
    
    next();
  };
};