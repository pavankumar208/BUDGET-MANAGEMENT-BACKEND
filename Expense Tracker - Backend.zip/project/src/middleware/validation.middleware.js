const { validationResult, body } = require('express-validator');
const { errorResponse } = require('./error.middleware');

/**
 * Middleware to handle validation errors
 */
exports.validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return errorResponse(
      res, 
      400, 
      'Validation Error', 
      errors.array().map(error => ({ field: error.param, message: error.msg }))
    );
  }
  next();
};

/**
 * User registration validation rules
 */
exports.registerValidation = [
  body('name').notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('Please include a valid email'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters')
];

/**
 * User login validation rules
 */
exports.loginValidation = [
  body('email').isEmail().withMessage('Please include a valid email'),
  body('password').notEmpty().withMessage('Password is required')
];

/**
 * Expense validation rules
 */
exports.expenseValidation = [
  body('amount')
    .isNumeric()
    .withMessage('Amount must be a number')
    .isFloat({ min: 0.01 })
    .withMessage('Amount must be greater than 0'),
  body('description')
    .notEmpty()
    .withMessage('Description is required'),
  body('category')
    .notEmpty()
    .withMessage('Category is required'),
  body('date')
    .optional()
    .isISO8601()
    .withMessage('Date must be a valid date')
];

/**
 * Income validation rules
 */
exports.incomeValidation = [
  body('amount')
    .isNumeric()
    .withMessage('Amount must be a number')
    .isFloat({ min: 0.01 })
    .withMessage('Amount must be greater than 0'),
  body('source')
    .notEmpty()
    .withMessage('Source is required'),
  body('description')
    .optional(),
  body('date')
    .optional()
    .isISO8601()
    .withMessage('Date must be a valid date')
];

/**
 * Budget validation rules
 */
exports.budgetValidation = [
  body('category')
    .notEmpty()
    .withMessage('Category is required'),
  body('limit')
    .isNumeric()
    .withMessage('Limit must be a number')
    .isFloat({ min: 0.01 })
    .withMessage('Limit must be greater than 0'),
  body('month')
    .notEmpty()
    .withMessage('Month is required')
    .matches(/^(0?[1-9]|1[0-2])$/)
    .withMessage('Month must be between 1-12'),
  body('year')
    .notEmpty()
    .withMessage('Year is required')
    .isInt({ min: 2000, max: 2100 })
    .withMessage('Year must be a valid year')
];