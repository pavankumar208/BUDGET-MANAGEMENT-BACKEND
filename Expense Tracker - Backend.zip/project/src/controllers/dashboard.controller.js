const Expense = require('../models/expense.model');
const Income = require('../models/income.model');
const Budget = require('../models/budget.model');

/**
 * @desc    Get dashboard summary data
 * @route   GET /api/dashboard
 * @access  Private
 */
exports.getDashboardSummary = async (req, res, next) => {
  try {
    // Get month and year from query or use current month/year
    let { month, year } = req.query;
    
    const now = new Date();
    month = month ? parseInt(month) : now.getMonth() + 1;
    year = year ? parseInt(year) : now.getFullYear();
    
    // Set date range for the month
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59);
    
    // Get total expense for the month
    const totalExpense = await Expense.aggregate([
      {
        $match: {
          user: req.user._id,
          date: { $gte: startDate, $lte: endDate },
          isDeleted: false
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$amount' }
        }
      }
    ]);
    
    // Get total income for the month
    const totalIncome = await Income.aggregate([
      {
        $match: {
          user: req.user._id,
          date: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$amount' }
        }
      }
    ]);
    
    // Get top spending categories
    const topCategories = await Expense.aggregate([
      {
        $match: {
          user: req.user._id,
          date: { $gte: startDate, $lte: endDate },
          isDeleted: false
        }
      },
      {
        $group: {
          _id: '$category',
          total: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { total: -1 }
      },
      {
        $limit: 5
      }
    ]);
    
    // Get recent transactions
    const recentExpenses = await Expense.find({
      user: req.user._id,
      isDeleted: false
    })
      .sort({ date: -1 })
      .limit(5);
    
    const recentIncomes = await Income.find({
      user: req.user._id
    })
      .sort({ date: -1 })
      .limit(2);
    
    // Combine and sort recent transactions
    const recentTransactions = [
      ...recentExpenses.map(expense => ({
        id: expense._id,
        type: 'expense',
        amount: expense.amount,
        description: expense.description,
        category: expense.category,
        date: expense.date
      })),
      ...recentIncomes.map(income => ({
        id: income._id,
        type: 'income',
        amount: income.amount,
        description: income.description || income.source,
        category: income.source,
        date: income.date
      }))
    ]
      .sort((a, b) => b.date - a.date)
      .slice(0, 5);
    
    // Get budget status
    const budgets = await Budget.find({
      user: req.user._id,
      month,
      year
    });
    
    // Calculate total budget amount
    const totalBudget = budgets.reduce((sum, budget) => sum + budget.limit, 0);
    
    // Prepare budget progress data
    let budgetProgress = 0;
    if (totalBudget > 0 && totalExpense.length > 0) {
      budgetProgress = (totalExpense[0].total / totalBudget) * 100;
    }
    
    // Get month-to-month comparison
    const previousMonth = month === 1 ? 12 : month - 1;
    const previousYear = month === 1 ? year - 1 : year;
    
    const previousStartDate = new Date(previousYear, previousMonth - 1, 1);
    const previousEndDate = new Date(previousYear, previousMonth, 0, 23, 59, 59);
    
    // Get previous month expense
    const previousExpense = await Expense.aggregate([
      {
        $match: {
          user: req.user._id,
          date: { $gte: previousStartDate, $lte: previousEndDate },
          isDeleted: false
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$amount' }
        }
      }
    ]);
    
    // Calculate expense change percentage
    let expenseChange = 0;
    if (previousExpense.length > 0 && totalExpense.length > 0 && previousExpense[0].total > 0) {
      expenseChange = ((totalExpense[0].total - previousExpense[0].total) / previousExpense[0].total) * 100;
    }
    
    res.status(200).json({
      success: true,
      data: {
        totalExpense: totalExpense.length > 0 ? totalExpense[0].total : 0,
        totalIncome: totalIncome.length > 0 ? totalIncome[0].total : 0,
        balance: (totalIncome.length > 0 ? totalIncome[0].total : 0) - (totalExpense.length > 0 ? totalExpense[0].total : 0),
        topCategories: topCategories.map(cat => ({
          category: cat._id,
          amount: cat.total,
          count: cat.count,
          percentage: totalExpense.length > 0 
            ? ((cat.total / totalExpense[0].total) * 100).toFixed(1) 
            : 0
        })),
        recentTransactions,
        budget: {
          total: totalBudget,
          used: totalExpense.length > 0 ? totalExpense[0].total : 0,
          remaining: totalBudget - (totalExpense.length > 0 ? totalExpense[0].total : 0),
          progress: budgetProgress.toFixed(1),
          status: budgetProgress > 100 ? 'exceeded' : 'within'
        },
        comparison: {
          currentMonth: {
            month,
            year,
            total: totalExpense.length > 0 ? totalExpense[0].total : 0
          },
          previousMonth: {
            month: previousMonth,
            year: previousYear,
            total: previousExpense.length > 0 ? previousExpense[0].total : 0
          },
          change: expenseChange.toFixed(1),
          trend: expenseChange > 0 ? 'increase' : (expenseChange < 0 ? 'decrease' : 'stable')
        }
      }
    });
  } catch (err) {
    next(err);
  }
};