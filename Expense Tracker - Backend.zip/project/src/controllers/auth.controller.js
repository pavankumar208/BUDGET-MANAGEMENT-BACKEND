const User = require('../models/user.model');
const jwt = require('jsonwebtoken');
const { errorResponse } = require('../middleware/error.middleware');

/**
 * @desc    Register user
 * @route   POST /api/auth/register
 * @access  Public
 */
exports.register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      return errorResponse(res, 400, 'User already exists');
    }

    // Create user
    const user = await User.create({
      name,
      email,
      password
    });

    // Generate tokens
    const token = user.getSignedJwtToken();
    const refreshToken = user.getRefreshToken();
    
    // Save refresh token
    user.refreshToken = refreshToken;
    await user.save();

    sendTokenResponse(res, 201, user, token, refreshToken);
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Login user
 * @route   POST /api/auth/login
 * @access  Public
 */
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await User.findOne({ email }).select('+password');
    
    if (!user) {
      return errorResponse(res, 401, 'Invalid credentials');
    }
    
    // Check password
    const isMatch = await user.matchPassword(password);
    
    if (!isMatch) {
      return errorResponse(res, 401, 'Invalid credentials');
    }
    
    // Generate tokens
    const token = user.getSignedJwtToken();
    const refreshToken = user.getRefreshToken();
    
    // Save refresh token
    user.refreshToken = refreshToken;
    await user.save();

    sendTokenResponse(res, 200, user, token, refreshToken);
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Refresh access token
 * @route   POST /api/auth/refresh
 * @access  Public
 */
exports.refreshToken = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    
    if (!refreshToken) {
      return errorResponse(res, 400, 'Refresh token is required');
    }
    
    // Verify refresh token
    let decoded;
    try {
      decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET);
    } catch (error) {
      return errorResponse(res, 401, 'Invalid refresh token');
    }
    
    // Find user with matching refresh token
    const user = await User.findOne({
      _id: decoded.id,
      refreshToken
    });
    
    if (!user) {
      return errorResponse(res, 401, 'Invalid refresh token');
    }
    
    // Generate new tokens
    const newToken = user.getSignedJwtToken();
    const newRefreshToken = user.getRefreshToken();
    
    // Update refresh token in database
    user.refreshToken = newRefreshToken;
    await user.save();
    
    res.status(200).json({
      success: true,
      token: newToken,
      refreshToken: newRefreshToken
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Logout user / clear refresh token
 * @route   POST /api/auth/logout
 * @access  Private
 */
exports.logout = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    
    if (!refreshToken) {
      return errorResponse(res, 400, 'Refresh token is required');
    }
    
    // Find user by refresh token and clear it
    const user = await User.findOneAndUpdate(
      { refreshToken },
      { refreshToken: null },
      { new: true }
    );
    
    res.status(200).json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (err) {
    next(err);
  }
};

/**
 * Helper function to send token response
 */
const sendTokenResponse = (res, statusCode, user, token, refreshToken) => {
  // Remove password from output
  user.password = undefined;
  user.refreshToken = undefined;
  
  res.status(statusCode).json({
    success: true,
    token,
    refreshToken,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      currency: user.currency,
      darkMode: user.darkMode,
      createdAt: user.createdAt
    }
  });
};