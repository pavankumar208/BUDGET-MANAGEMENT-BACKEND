const Expense = require('../models/expense.model');
const { errorResponse } = require('../middleware/error.middleware');

/**
 * @desc    Get all expenses
 * @route   GET /api/expenses
 * @access  Private
 */
exports.getExpenses = async (req, res, next) => {
  try {
    // Extract query parameters
    const { 
      from, 
      to, 
      category, 
      limit = 10, 
      page = 1,
      sort = '-date'
    } = req.query;
    
    // Build query
    const query = { user: req.user._id, isDeleted: false };
    
    // Add date filters if provided
    if (from || to) {
      query.date = {};
      if (from) query.date.$gte = new Date(from);
      if (to) query.date.$lte = new Date(to);
    }
    
    // Add category filter if provided
    if (category) query.category = category;
    
    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Execute query with pagination
    const expenses = await Expense.find(query)
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit));
    
    // Get total count for pagination
    const total = await Expense.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: expenses.length,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / parseInt(limit))
      },
      data: expenses
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Get single expense
 * @route   GET /api/expenses/:id
 * @access  Private
 */
exports.getExpense = async (req, res, next) => {
  try {
    const expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user._id,
      isDeleted: false
    });
    
    if (!expense) {
      return errorResponse(res, 404, 'Expense not found');
    }
    
    res.status(200).json({
      success: true,
      data: expense
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Create new expense
 * @route   POST /api/expenses
 * @access  Private
 */
exports.createExpense = async (req, res, next) => {
  try {
    // Add user to request body
    req.body.user = req.user._id;
    
    // Create expense
    const expense = await Expense.create(req.body);
    
    res.status(201).json({
      success: true,
      data: expense
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Update expense
 * @route   PUT /api/expenses/:id
 * @access  Private
 */
exports.updateExpense = async (req, res, next) => {
  try {
    // Find expense
    let expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user._id,
      isDeleted: false
    });
    
    if (!expense) {
      return errorResponse(res, 404, 'Expense not found');
    }
    
    // Update expense
    expense = await Expense.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    res.status(200).json({
      success: true,
      data: expense
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Delete expense
 * @route   DELETE /api/expenses/:id
 * @access  Private
 */
exports.deleteExpense = async (req, res, next) => {
  try {
    // Find expense
    const expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user._id
    });
    
    if (!expense) {
      return errorResponse(res, 404, 'Expense not found');
    }
    
    // Soft delete (mark as deleted)
    expense.isDeleted = true;
    await expense.save();
    
    // Alternative: Hard delete
    // await expense.remove();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    next(err);
  }
};