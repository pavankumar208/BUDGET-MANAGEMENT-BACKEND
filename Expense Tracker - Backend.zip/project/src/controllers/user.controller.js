const User = require('../models/user.model');
const { errorResponse } = require('../middleware/error.middleware');
const bcrypt = require('bcryptjs');

/**
 * @desc    Get user profile
 * @route   GET /api/user/profile
 * @access  Private
 */
exports.getProfile = async (req, res, next) => {
  try {
    // User is already available in req.user from the protect middleware
    res.status(200).json({
      success: true,
      data: {
        id: req.user._id,
        name: req.user.name,
        email: req.user.email,
        role: req.user.role,
        currency: req.user.currency,
        darkMode: req.user.darkMode,
        createdAt: req.user.createdAt
      }
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Update user profile
 * @route   PUT /api/user/profile
 * @access  Private
 */
exports.updateProfile = async (req, res, next) => {
  try {
    const { name, email } = req.body;
    
    // Build update object
    const updateFields = {};
    if (name) updateFields.name = name;
    if (email) updateFields.email = email;
    
    // Check if email is being changed and already exists
    if (email && email !== req.user.email) {
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return errorResponse(res, 400, 'Email already in use');
      }
    }
    
    // Update user
    const updatedUser = await User.findByIdAndUpdate(
      req.user._id,
      updateFields,
      { new: true, runValidators: true }
    );
    
    res.status(200).json({
      success: true,
      data: {
        id: updatedUser._id,
        name: updatedUser.name,
        email: updatedUser.email,
        role: updatedUser.role,
        currency: updatedUser.currency,
        darkMode: updatedUser.darkMode,
        createdAt: updatedUser.createdAt
      }
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Update user password
 * @route   PUT /api/user/password
 * @access  Private
 */
exports.updatePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return errorResponse(res, 400, 'Current password and new password are required');
    }
    
    // Get user with password
    const user = await User.findById(req.user._id).select('+password');
    
    // Check current password
    const isMatch = await user.matchPassword(currentPassword);
    if (!isMatch) {
      return errorResponse(res, 401, 'Current password is incorrect');
    }
    
    // Update password
    user.password = newPassword;
    await user.save();
    
    res.status(200).json({
      success: true,
      message: 'Password updated successfully'
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Update user preferences
 * @route   PUT /api/user/preferences
 * @access  Private
 */
exports.updatePreferences = async (req, res, next) => {
  try {
    const { currency, darkMode } = req.body;
    
    // Build update object
    const updateFields = {};
    if (currency !== undefined) updateFields.currency = currency;
    if (darkMode !== undefined) updateFields.darkMode = darkMode;
    
    // Update user
    const updatedUser = await User.findByIdAndUpdate(
      req.user._id,
      updateFields,
      { new: true, runValidators: true }
    );
    
    res.status(200).json({
      success: true,
      data: {
        id: updatedUser._id,
        name: updatedUser.name,
        email: updatedUser.email,
        role: updatedUser.role,
        currency: updatedUser.currency,
        darkMode: updatedUser.darkMode,
        createdAt: updatedUser.createdAt
      }
    });
  } catch (err) {
    next(err);
  }
};