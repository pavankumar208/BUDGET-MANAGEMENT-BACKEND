const Expense = require('../models/expense.model');
const Income = require('../models/income.model');
const { errorResponse } = require('../middleware/error.middleware');

/**
 * @desc    Get monthly expense report
 * @route   GET /api/report/monthly/:month/:year
 * @access  Private
 */
exports.getMonthlyReport = async (req, res, next) => {
  try {
    const { month, year } = req.params;
    
    // Validate month/year
    const monthNum = parseInt(month);
    const yearNum = parseInt(year);
    
    if (monthNum < 1 || monthNum > 12) {
      return errorResponse(res, 400, 'Month must be between 1 and 12');
    }
    
    // Get date range for month
    const startDate = new Date(yearNum, monthNum - 1, 1);
    const endDate = new Date(yearNum, monthNum, 0, 23, 59, 59);
    
    // Get all expenses for the month
    const expenses = await Expense.find({
      user: req.user._id,
      date: { $gte: startDate, $lte: endDate },
      isDeleted: false
    }).sort('date');
    
    // Get all income for the month
    const incomes = await Income.find({
      user: req.user._id,
      date: { $gte: startDate, $lte: endDate }
    }).sort('date');
    
    // Daily breakdown
    const days = [];
    for (let day = 1; day <= endDate.getDate(); day++) {
      const dayExpenses = expenses.filter(expense => {
        return expense.date.getDate() === day;
      });
      
      const dayIncomes = incomes.filter(income => {
        return income.date.getDate() === day;
      });
      
      days.push({
        day,
        expenses: dayExpenses,
        totalExpense: dayExpenses.reduce((sum, expense) => sum + expense.amount, 0),
        incomes: dayIncomes,
        totalIncome: dayIncomes.reduce((sum, income) => sum + income.amount, 0)
      });
    }
    
    // Calculate category breakdown
    const categoryBreakdown = {};
    expenses.forEach(expense => {
      if (!categoryBreakdown[expense.category]) {
        categoryBreakdown[expense.category] = {
          total: 0,
          count: 0
        };
      }
      categoryBreakdown[expense.category].total += expense.amount;
      categoryBreakdown[expense.category].count += 1;
    });
    
    // Format category breakdown for charts
    const categoryChartData = Object.entries(categoryBreakdown).map(([category, data]) => ({
      label: category,
      value: data.total,
      count: data.count
    }));
    
    const totalExpense = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    const totalIncome = incomes.reduce((sum, income) => sum + income.amount, 0);
    
    res.status(200).json({
      success: true,
      data: {
        month: monthNum,
        year: yearNum,
        days,
        categories: categoryChartData,
        summary: {
          totalExpense,
          totalIncome,
          balance: totalIncome - totalExpense,
          expenseCount: expenses.length,
          incomeCount: incomes.length,
          categoryCount: Object.keys(categoryBreakdown).length
        }
      }
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Get expense breakdown by category
 * @route   GET /api/report/category-wise
 * @access  Private
 */
exports.getCategoryWiseReport = async (req, res, next) => {
  try {
    const { from, to } = req.query;
    
    // Build date range filter
    const dateFilter = {};
    if (from || to) {
      dateFilter.date = {};
      if (from) dateFilter.date.$gte = new Date(from);
      if (to) dateFilter.date.$lte = new Date(to);
    }
    
    // Get expenses
    const expenses = await Expense.find({
      user: req.user._id,
      ...dateFilter,
      isDeleted: false
    });
    
    // Group by category
    const categoryData = {};
    expenses.forEach(expense => {
      if (!categoryData[expense.category]) {
        categoryData[expense.category] = 0;
      }
      categoryData[expense.category] += expense.amount;
    });
    
    // Format for charts
    const chartData = Object.entries(categoryData)
      .map(([category, amount]) => ({
        label: category,
        value: amount
      }))
      .sort((a, b) => b.value - a.value);
    
    const totalExpense = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    
    // Calculate percentages
    const chartDataWithPercentage = chartData.map(item => ({
      ...item,
      percentage: ((item.value / totalExpense) * 100).toFixed(2)
    }));
    
    res.status(200).json({
      success: true,
      data: {
        totalExpense,
        categories: chartDataWithPercentage
      }
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Get income vs expense comparison
 * @route   GET /api/report/income-vs-expense
 * @access  Private
 */
exports.getIncomeVsExpenseReport = async (req, res, next) => {
  try {
    const { from, to } = req.query;
    
    // Build date range filter
    const dateFilter = {};
    if (from || to) {
      dateFilter.date = {};
      if (from) dateFilter.date.$gte = new Date(from);
      if (to) dateFilter.date.$lte = new Date(to);
    }
    
    // Get expenses
    const expenses = await Expense.find({
      user: req.user._id,
      ...dateFilter,
      isDeleted: false
    });
    
    // Get incomes
    const incomes = await Income.find({
      user: req.user._id,
      ...dateFilter
    });
    
    // Group by month
    const monthlyData = {};
    
    // Process expenses
    expenses.forEach(expense => {
      const monthKey = `${expense.date.getFullYear()}-${expense.date.getMonth() + 1}`;
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = {
          month: expense.date.getMonth() + 1,
          year: expense.date.getFullYear(),
          expense: 0,
          income: 0
        };
      }
      monthlyData[monthKey].expense += expense.amount;
    });
    
    // Process incomes
    incomes.forEach(income => {
      const monthKey = `${income.date.getFullYear()}-${income.date.getMonth() + 1}`;
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = {
          month: income.date.getMonth() + 1,
          year: income.date.getFullYear(),
          expense: 0,
          income: 0
        };
      }
      monthlyData[monthKey].income += income.amount;
    });
    
    // Convert to array and sort by date
    const monthlyComparison = Object.values(monthlyData).sort((a, b) => {
      if (a.year !== b.year) return a.year - b.year;
      return a.month - b.month;
    });
    
    // Add additional calculations
    const comparisonWithSavings = monthlyComparison.map(month => ({
      ...month,
      savings: month.income - month.expense,
      savingsRate: month.income > 0 
        ? ((month.income - month.expense) / month.income * 100).toFixed(2) 
        : 0
    }));
    
    // Calculate totals
    const totalIncome = incomes.reduce((sum, income) => sum + income.amount, 0);
    const totalExpense = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    
    res.status(200).json({
      success: true,
      data: {
        monthly: comparisonWithSavings,
        summary: {
          totalIncome,
          totalExpense,
          savings: totalIncome - totalExpense,
          savingsRate: totalIncome > 0 
            ? ((totalIncome - totalExpense) / totalIncome * 100).toFixed(2)
            : 0,
          months: comparisonWithSavings.length
        }
      }
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Get expense trends over time
 * @route   GET /api/report/trends
 * @access  Private
 */
exports.getTrendsReport = async (req, res, next) => {
  try {
    const { months = 6 } = req.query;
    const monthsCount = parseInt(months);
    
    // Calculate date range (last N months)
    const endDate = new Date();
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - (monthsCount - 1));
    startDate.setDate(1);
    startDate.setHours(0, 0, 0, 0);
    
    // Get all expenses in the date range
    const expenses = await Expense.find({
      user: req.user._id,
      date: { $gte: startDate, $lte: endDate },
      isDeleted: false
    }).sort('date');
    
    // Generate all month-year combinations in the range
    const monthsRange = [];
    const currentDate = new Date(startDate);
    
    while (currentDate <= endDate) {
      monthsRange.push({
        month: currentDate.getMonth() + 1,
        year: currentDate.getFullYear(),
        key: `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}`
      });
      currentDate.setMonth(currentDate.getMonth() + 1);
    }
    
    // Group expenses by month and category
    const trendData = {};
    
    // Initialize with zero values for all months and categories
    const uniqueCategories = [...new Set(expenses.map(expense => expense.category))];
    
    monthsRange.forEach(monthYear => {
      trendData[monthYear.key] = {
        month: monthYear.month,
        year: monthYear.year,
        total: 0,
        categories: {}
      };
      
      uniqueCategories.forEach(category => {
        trendData[monthYear.key].categories[category] = 0;
      });
    });
    
    // Fill in actual expense data
    expenses.forEach(expense => {
      const monthKey = `${expense.date.getFullYear()}-${expense.date.getMonth() + 1}`;
      if (trendData[monthKey]) {
        trendData[monthKey].total += expense.amount;
        trendData[monthKey].categories[expense.category] += expense.amount;
      }
    });
    
    // Format for chart data
    const trendChartData = Object.values(trendData).map(monthData => {
      const categoryValues = {};
      Object.entries(monthData.categories).forEach(([category, amount]) => {
        categoryValues[category] = amount;
      });
      
      return {
        month: monthData.month,
        year: monthData.year,
        monthName: new Date(monthData.year, monthData.month - 1, 1).toLocaleString('default', { month: 'short' }),
        total: monthData.total,
        ...categoryValues
      };
    });
    
    // Calculate growth and trends
    const analysis = [];
    for (let i = 1; i < trendChartData.length; i++) {
      const currentMonth = trendChartData[i];
      const previousMonth = trendChartData[i - 1];
      
      const growth = ((currentMonth.total - previousMonth.total) / previousMonth.total) * 100;
      
      analysis.push({
        month: currentMonth.month,
        year: currentMonth.year,
        monthName: currentMonth.monthName,
        currentTotal: currentMonth.total,
        previousTotal: previousMonth.total,
        growth: growth.toFixed(2),
        trend: growth > 0 ? 'increase' : (growth < 0 ? 'decrease' : 'stable')
      });
    }
    
    res.status(200).json({
      success: true,
      data: {
        trends: trendChartData,
        categories: uniqueCategories,
        analysis
      }
    });
  } catch (err) {
    next(err);
  }
};