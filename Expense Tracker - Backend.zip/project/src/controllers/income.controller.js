const Income = require('../models/income.model');
const { errorResponse } = require('../middleware/error.middleware');

/**
 * @desc    Get all income entries
 * @route   GET /api/income
 * @access  Private
 */
exports.getIncomes = async (req, res, next) => {
  try {
    // Extract query parameters
    const { 
      from, 
      to, 
      source, 
      limit = 10, 
      page = 1,
      sort = '-date'
    } = req.query;
    
    // Build query
    const query = { user: req.user._id };
    
    // Add date filters if provided
    if (from || to) {
      query.date = {};
      if (from) query.date.$gte = new Date(from);
      if (to) query.date.$lte = new Date(to);
    }
    
    // Add source filter if provided
    if (source) query.source = source;
    
    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Execute query with pagination
    const incomes = await Income.find(query)
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit));
    
    // Get total count for pagination
    const total = await Income.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: incomes.length,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / parseInt(limit))
      },
      data: incomes
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Get single income entry
 * @route   GET /api/income/:id
 * @access  Private
 */
exports.getIncome = async (req, res, next) => {
  try {
    const income = await Income.findOne({
      _id: req.params.id,
      user: req.user._id
    });
    
    if (!income) {
      return errorResponse(res, 404, 'Income entry not found');
    }
    
    res.status(200).json({
      success: true,
      data: income
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Create new income entry
 * @route   POST /api/income
 * @access  Private
 */
exports.createIncome = async (req, res, next) => {
  try {
    // Add user to request body
    req.body.user = req.user._id;
    
    // Create income
    const income = await Income.create(req.body);
    
    res.status(201).json({
      success: true,
      data: income
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Update income entry
 * @route   PUT /api/income/:id
 * @access  Private
 */
exports.updateIncome = async (req, res, next) => {
  try {
    // Find income
    let income = await Income.findOne({
      _id: req.params.id,
      user: req.user._id
    });
    
    if (!income) {
      return errorResponse(res, 404, 'Income entry not found');
    }
    
    // Update income
    income = await Income.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    res.status(200).json({
      success: true,
      data: income
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Delete income entry
 * @route   DELETE /api/income/:id
 * @access  Private
 */
exports.deleteIncome = async (req, res, next) => {
  try {
    // Find income
    const income = await Income.findOne({
      _id: req.params.id,
      user: req.user._id
    });
    
    if (!income) {
      return errorResponse(res, 404, 'Income entry not found');
    }
    
    // Delete income
    await income.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    next(err);
  }
};