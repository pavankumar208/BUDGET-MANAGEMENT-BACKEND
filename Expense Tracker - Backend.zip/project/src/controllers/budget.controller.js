const Budget = require('../models/budget.model');
const Expense = require('../models/expense.model');
const { errorResponse } = require('../middleware/error.middleware');

/**
 * @desc    Get all budgets
 * @route   GET /api/budget
 * @access  Private
 */
exports.getBudgets = async (req, res, next) => {
  try {
    // Extract query parameters
    const { month, year } = req.query;
    
    // Build query
    const query = { user: req.user._id };
    
    // Add month/year filters if provided
    if (month) query.month = parseInt(month);
    if (year) query.year = parseInt(year);
    
    // Execute query
    const budgets = await Budget.find(query).sort('category');
    
    res.status(200).json({
      success: true,
      count: budgets.length,
      data: budgets
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Get single budget
 * @route   GET /api/budget/:id
 * @access  Private
 */
exports.getBudget = async (req, res, next) => {
  try {
    const budget = await Budget.findOne({
      _id: req.params.id,
      user: req.user._id
    });
    
    if (!budget) {
      return errorResponse(res, 404, 'Budget not found');
    }
    
    res.status(200).json({
      success: true,
      data: budget
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Create new budget
 * @route   POST /api/budget
 * @access  Private
 */
exports.createBudget = async (req, res, next) => {
  try {
    // Add user to request body
    req.body.user = req.user._id;
    
    // Check if budget for this category/month/year already exists
    const existingBudget = await Budget.findOne({
      user: req.user._id,
      category: req.body.category,
      month: req.body.month,
      year: req.body.year
    });
    
    if (existingBudget) {
      return errorResponse(res, 400, 'Budget for this category and month already exists');
    }
    
    // Create budget
    const budget = await Budget.create(req.body);
    
    res.status(201).json({
      success: true,
      data: budget
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Update budget
 * @route   PUT /api/budget/:id
 * @access  Private
 */
exports.updateBudget = async (req, res, next) => {
  try {
    // Find budget
    let budget = await Budget.findOne({
      _id: req.params.id,
      user: req.user._id
    });
    
    if (!budget) {
      return errorResponse(res, 404, 'Budget not found');
    }
    
    // If category/month/year is changing, check for duplicates
    if (
      (req.body.category && req.body.category !== budget.category) ||
      (req.body.month && req.body.month !== budget.month) ||
      (req.body.year && req.body.year !== budget.year)
    ) {
      const existingBudget = await Budget.findOne({
        user: req.user._id,
        category: req.body.category || budget.category,
        month: req.body.month || budget.month,
        year: req.body.year || budget.year,
        _id: { $ne: budget._id }
      });
      
      if (existingBudget) {
        return errorResponse(res, 400, 'Budget for this category and month already exists');
      }
    }
    
    // Update budget
    budget = await Budget.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    res.status(200).json({
      success: true,
      data: budget
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Delete budget
 * @route   DELETE /api/budget/:id
 * @access  Private
 */
exports.deleteBudget = async (req, res, next) => {
  try {
    // Find budget
    const budget = await Budget.findOne({
      _id: req.params.id,
      user: req.user._id
    });
    
    if (!budget) {
      return errorResponse(res, 404, 'Budget not found');
    }
    
    // Delete budget
    await budget.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    next(err);
  }
};

/**
 * @desc    Get budget status with spending vs limits
 * @route   GET /api/budget/status/:month/:year
 * @access  Private
 */
exports.getBudgetStatus = async (req, res, next) => {
  try {
    const { month, year } = req.params;
    
    // Validate month/year
    const monthNum = parseInt(month);
    const yearNum = parseInt(year);
    
    if (monthNum < 1 || monthNum > 12) {
      return errorResponse(res, 400, 'Month must be between 1 and 12');
    }
    
    // Get all budgets for the month/year
    const budgets = await Budget.find({
      user: req.user._id,
      month: monthNum,
      year: yearNum
    });
    
    // Get all expenses for the month/year
    const startDate = new Date(yearNum, monthNum - 1, 1);
    const endDate = new Date(yearNum, monthNum, 0, 23, 59, 59);
    
    const expenses = await Expense.find({
      user: req.user._id,
      date: { $gte: startDate, $lte: endDate },
      isDeleted: false
    });
    
    // Calculate spending by category
    const spendingByCategory = {};
    expenses.forEach(expense => {
      if (!spendingByCategory[expense.category]) {
        spendingByCategory[expense.category] = 0;
      }
      spendingByCategory[expense.category] += expense.amount;
    });
    
    // Combine budget and spending data
    const budgetStatus = budgets.map(budget => {
      const spent = spendingByCategory[budget.category] || 0;
      const remaining = budget.limit - spent;
      const percentage = (spent / budget.limit) * 100;
      
      return {
        id: budget._id,
        category: budget.category,
        limit: budget.limit,
        spent,
        remaining,
        percentage: Math.min(percentage, 100).toFixed(2),
        status: percentage > 100 ? 'exceeded' : 'within'
      };
    });
    
    // Add categories with spending but no budget
    const categoriesWithoutBudget = Object.keys(spendingByCategory)
      .filter(category => !budgets.find(b => b.category === category))
      .map(category => ({
        category,
        limit: 0,
        spent: spendingByCategory[category],
        remaining: -spendingByCategory[category],
        percentage: 100,
        status: 'no-budget'
      }));
    
    res.status(200).json({
      success: true,
      data: {
        budgetStatus: [...budgetStatus, ...categoriesWithoutBudget],
        totalBudget: budgets.reduce((sum, budget) => sum + budget.limit, 0),
        totalSpent: Object.values(spendingByCategory).reduce((sum, val) => sum + val, 0)
      }
    });
  } catch (err) {
    next(err);
  }
};