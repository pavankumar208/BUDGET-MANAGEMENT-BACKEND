const express = require('express');
const router = express.Router();
const {
  getMonthlyReport,
  getCategoryWiseReport,
  getIncomeVsExpenseReport,
  getTrendsReport
} = require('../controllers/report.controller');
const { protect } = require('../middleware/auth.middleware');

/**
 * @swagger
 * /api/report/monthly/{month}/{year}:
 *   get:
 *     summary: Get monthly expense report
 *     tags: [Reports]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: month
 *         required: true
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 12
 *         description: Month (1-12)
 *       - in: path
 *         name: year
 *         required: true
 *         schema:
 *           type: integer
 *         description: Year
 *     responses:
 *       200:
 *         description: Monthly expense report
 *       401:
 *         description: Not authorized
 */
router.get('/monthly/:month/:year', protect, getMonthlyReport);

/**
 * @swagger
 * /api/report/category-wise:
 *   get:
 *     summary: Get expense breakdown by category
 *     tags: [Reports]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: from
 *         schema:
 *           type: string
 *           format: date
 *         description: Start date for filtering
 *       - in: query
 *         name: to
 *         schema:
 *           type: string
 *           format: date
 *         description: End date for filtering
 *     responses:
 *       200:
 *         description: Category-wise expense breakdown
 *       401:
 *         description: Not authorized
 */
router.get('/category-wise', protect, getCategoryWiseReport);

/**
 * @swagger
 * /api/report/income-vs-expense:
 *   get:
 *     summary: Get income vs expense comparison
 *     tags: [Reports]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: from
 *         schema:
 *           type: string
 *           format: date
 *         description: Start date for filtering
 *       - in: query
 *         name: to
 *         schema:
 *           type: string
 *           format: date
 *         description: End date for filtering
 *     responses:
 *       200:
 *         description: Income vs expense comparison
 *       401:
 *         description: Not authorized
 */
router.get('/income-vs-expense', protect, getIncomeVsExpenseReport);

/**
 * @swagger
 * /api/report/trends:
 *   get:
 *     summary: Get expense trends over time
 *     tags: [Reports]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: months
 *         schema:
 *           type: integer
 *           default: 6
 *         description: Number of months to include
 *     responses:
 *       200:
 *         description: Expense trends over time
 *       401:
 *         description: Not authorized
 */
router.get('/trends', protect, getTrendsReport);

module.exports = router;