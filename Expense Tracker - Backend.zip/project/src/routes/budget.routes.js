const express = require('express');
const router = express.Router();
const {
  getBudgets,
  getBudget,
  createBudget,
  updateBudget,
  deleteBudget,
  getBudgetStatus
} = require('../controllers/budget.controller');
const { protect } = require('../middleware/auth.middleware');
const { budgetValidation, validateRequest } = require('../middleware/validation.middleware');

/**
 * @swagger
 * /api/budget:
 *   get:
 *     summary: Get all budgets for the user
 *     tags: [Budget]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: month
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 12
 *         description: Month (1-12)
 *       - in: query
 *         name: year
 *         schema:
 *           type: integer
 *         description: Year
 *     responses:
 *       200:
 *         description: List of budgets
 *       401:
 *         description: Not authorized
 */
router.get('/', protect, getBudgets);

/**
 * @swagger
 * /api/budget/{id}:
 *   get:
 *     summary: Get budget by ID
 *     tags: [Budget]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Budget ID
 *     responses:
 *       200:
 *         description: Budget details
 *       404:
 *         description: Budget not found
 *       401:
 *         description: Not authorized
 */
router.get('/:id', protect, getBudget);

/**
 * @swagger
 * /api/budget:
 *   post:
 *     summary: Create a new budget
 *     tags: [Budget]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Budget'
 *     responses:
 *       201:
 *         description: Budget created successfully
 *       400:
 *         description: Invalid input data
 *       401:
 *         description: Not authorized
 */
router.post('/', protect, budgetValidation, validateRequest, createBudget);

/**
 * @swagger
 * /api/budget/{id}:
 *   put:
 *     summary: Update budget
 *     tags: [Budget]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Budget ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Budget'
 *     responses:
 *       200:
 *         description: Budget updated successfully
 *       404:
 *         description: Budget not found
 *       401:
 *         description: Not authorized
 */
router.put('/:id', protect, budgetValidation, validateRequest, updateBudget);

/**
 * @swagger
 * /api/budget/{id}:
 *   delete:
 *     summary: Delete budget
 *     tags: [Budget]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Budget ID
 *     responses:
 *       200:
 *         description: Budget deleted successfully
 *       404:
 *         description: Budget not found
 *       401:
 *         description: Not authorized
 */
router.delete('/:id', protect, deleteBudget);

/**
 * @swagger
 * /api/budget/status/{month}/{year}:
 *   get:
 *     summary: Get budget status for a month/year
 *     tags: [Budget]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: month
 *         required: true
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 12
 *         description: Month (1-12)
 *       - in: path
 *         name: year
 *         required: true
 *         schema:
 *           type: integer
 *         description: Year
 *     responses:
 *       200:
 *         description: Budget status with spending vs limits
 *       401:
 *         description: Not authorized
 */
router.get('/status/:month/:year', protect, getBudgetStatus);

module.exports = router;