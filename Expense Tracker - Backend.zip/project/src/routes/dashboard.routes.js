const express = require('express');
const router = express.Router();
const {
  getDashboardSummary
} = require('../controllers/dashboard.controller');
const { protect } = require('../middleware/auth.middleware');

/**
 * @swagger
 * /api/dashboard:
 *   get:
 *     summary: Get dashboard summary data
 *     tags: [Dashboard]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: month
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 12
 *         description: Month (1-12) - defaults to current month
 *       - in: query
 *         name: year
 *         schema:
 *           type: integer
 *         description: Year - defaults to current year
 *     responses:
 *       200:
 *         description: Dashboard summary data
 *       401:
 *         description: Not authorized
 */
router.get('/', protect, getDashboardSummary);

module.exports = router;