const express = require('express');
const router = express.Router();
const {
  getIncomes,
  getIncome,
  createIncome,
  updateIncome,
  deleteIncome
} = require('../controllers/income.controller');
const { protect } = require('../middleware/auth.middleware');
const { incomeValidation, validateRequest } = require('../middleware/validation.middleware');

/**
 * @swagger
 * /api/income:
 *   get:
 *     summary: Get all income entries for the user
 *     tags: [Income]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: from
 *         schema:
 *           type: string
 *           format: date
 *         description: Start date for filtering
 *       - in: query
 *         name: to
 *         schema:
 *           type: string
 *           format: date
 *         description: End date for filtering
 *       - in: query
 *         name: source
 *         schema:
 *           type: string
 *         description: Filter by source
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Number of records to return
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *     responses:
 *       200:
 *         description: List of income entries
 *       401:
 *         description: Not authorized
 */
router.get('/', protect, getIncomes);

/**
 * @swagger
 * /api/income/{id}:
 *   get:
 *     summary: Get income by ID
 *     tags: [Income]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Income ID
 *     responses:
 *       200:
 *         description: Income details
 *       404:
 *         description: Income not found
 *       401:
 *         description: Not authorized
 */
router.get('/:id', protect, getIncome);

/**
 * @swagger
 * /api/income:
 *   post:
 *     summary: Create a new income entry
 *     tags: [Income]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Income'
 *     responses:
 *       201:
 *         description: Income created successfully
 *       400:
 *         description: Invalid input data
 *       401:
 *         description: Not authorized
 */
router.post('/', protect, incomeValidation, validateRequest, createIncome);

/**
 * @swagger
 * /api/income/{id}:
 *   put:
 *     summary: Update income
 *     tags: [Income]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Income ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Income'
 *     responses:
 *       200:
 *         description: Income updated successfully
 *       404:
 *         description: Income not found
 *       401:
 *         description: Not authorized
 */
router.put('/:id', protect, incomeValidation, validateRequest, updateIncome);

/**
 * @swagger
 * /api/income/{id}:
 *   delete:
 *     summary: Delete income
 *     tags: [Income]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Income ID
 *     responses:
 *       200:
 *         description: Income deleted successfully
 *       404:
 *         description: Income not found
 *       401:
 *         description: Not authorized
 */
router.delete('/:id', protect, deleteIncome);

module.exports = router;